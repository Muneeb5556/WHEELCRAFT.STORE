const menu=document.querySelector('.menu-btn'),nav=document.querySelector('nav');menu.onclick=()=>nav.classList.toggle('open');document.querySelectorAll('nav a').forEach(a=>a.onclick=()=>nav.classList.remove('open'));
const modal=document.querySelector('.modal'),img=document.querySelector('#modalImg'),title=document.querySelector('#modalTitle');
document.querySelectorAll('.card').forEach(card=>card.querySelector('.details').onclick=()=>{img.src=card.dataset.img;title.textContent=card.dataset.title;modal.classList.add('open');modal.setAttribute('aria-hidden','false')});
document.querySelector('.close').onclick=()=>{modal.classList.remove('open');modal.setAttribute('aria-hidden','true')};
modal.onclick=e=>{if(e.target===modal){modal.classList.remove('open');modal.setAttribute('aria-hidden','true')}};
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add('visible')}),{threshold:.12});document.querySelectorAll('.reveal').forEach(x=>observer.observe(x));
